namespace Hedera.Hashgraph.Reference
{
    public interface ILedgerId
    {
        // TODO: ##### `fromNetworkName` ( `networkName`: [`NetworkName`]() ): `LedgerId`
        // TODO: ##### `toNetworkName` ( ): [`NetworkName`]()

        abstract static ILedgerId MAINNET { get; }
        abstract static ILedgerId TESTNET { get; }
        abstract static ILedgerId PREVIEWNET { get; }

        abstract static ILedgerId FromBytes(byte[] bytes);
        abstract static ILedgerId FromString(string ledgerId);

        bool IsMainnet { get; }
        bool IsTestnet { get; }
        bool IsPreviewnet { get; }

        string ToBytes();
        string ToString();
    }
}
