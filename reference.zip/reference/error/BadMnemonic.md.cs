// SPDX-License-Identifier: Apache-2.0
using System;
using System.Collections.Generic;

namespace Hedera.Hashgraph.Reference.Error
{
    /// <summary>
    /// Signals that a private or public key could not be realized from the input.
    /// </summary>
    public sealed class BadMnemonicException : ArgumentException
    {
        internal BadMnemonicException(Mnemonic mnemonic, BadMnemonicReason reason)
        {
            Mnemonic = mnemonic;
            Reason = reason;
            UnknownWordIndices = null;
        }
        internal BadMnemonicException(Mnemonic mnemonic, BadMnemonicReason reason, IEnumerable<int> unknownWordIndices)
        {
            Mnemonic = mnemonic;
            Reason = reason;
            UnknownWordIndices = [.. unknownWordIndices];
        }

        public Mnemonic Mnemonic { get; }
        public BadMnemonicReason Reason { get; }
        public List<int>? UnknownWordIndices { get; }
    }
}
