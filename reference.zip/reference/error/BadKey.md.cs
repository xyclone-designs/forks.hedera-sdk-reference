// SPDX-License-Identifier: Apache-2.0
using System;

namespace Hedera.Hashgraph.Reference.Error
{
    /// <summary>
    /// Signals that a private or public key could not be realized from the input.
    /// </summary>
    public sealed class BadKeyException : ArgumentException
    {
        internal BadKeyException(string message) : base(message) { }
		internal BadKeyException(Exception cause) : base(cause.Message, cause) { }
    }
}
