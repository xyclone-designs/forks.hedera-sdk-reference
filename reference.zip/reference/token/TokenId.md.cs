
namespace Hedera.Hashgraph.Reference.Token
{
    /// <summary>
    /// An ID type that represents a token on a Hedera Hashgraph network.
    /// </summary>
    public interface ITokenId
    {
        /// <summary>
        /// The shard of this ID.
        /// </summary>
        long Shard { get; }
        /// <summary>
        /// The realm of this ID.
        /// </summary> 
        long Realm { get; }
        /// <summary>
        /// The num of this ID.
        /// </summary>
        long Num { get; }

        /// <summary>
        /// Construct a [`TokenId`](#) with [`shard`](#shard-uint64) and [`realm`](#realm-uint64) being zero.
        /// </summary>
        /// <param name="num"></param>
        /// <returns>The token id</returns>
        abstract static ITokenId Constructor(long num);
        /// <summary>
        /// Construct a [`TokenId`](#) with all fields explicitly set.
        /// </summary>
        /// <param name="shard"></param>
        /// <param name="realm"></param>
        /// <param name="num"></param>
        /// <returns>The token id</returns>
        abstract static ITokenId Constructor(long shard, long realm, long num);

        /// <summary>
        /// Deserialize a [`TokenId`](#) from its the protobuf representation.
        /// </summary>
        /// <param name="bytes">Protobuf representation as byte array</param>
        /// <returns>The token id</returns>
        abstract static ITokenId FromBytes(byte[] bytes);
        /// <summary>
        /// Construct a [`TokenId`](#) from a string. The format of the string could be either just
        /// a number "4" or dot separated numbers "0.0.4".
        /// </summary>
        /// <param name="str">The string value of the token id</param>
        /// <returns>The token id</returns>
        abstract static ITokenId FromString(string str);

        /// <summary>
        /// Serialize the [`TokenId`](#) into its protobuf representation.
        /// </summary>
        /// <returns>Protobuf representation as byte array</returns>
        byte[] ToBytes();
    }
}
