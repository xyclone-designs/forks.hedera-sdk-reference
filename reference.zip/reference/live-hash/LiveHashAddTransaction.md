> class `LiveHashAddTransaction` extends [`Transaction`](reference/core/Transaction.md)

<!-- tabs:start -->

#### ** Java **

```java
new LiveHashAddTransaction()
    .setTopicId(topicId)
    .execute(client)
    .setNodeAccountIds(Collections.singletonList(response.nodeId))
    .getReceipt(client);
```

#### ** JavaScript **

```js
await (
    await new LiveHashAddTransaction().setTopicId(topic).execute(client)
).getReceipt(client);
```

#### ** Go **

```go
response, err = hedera.NewLiveHashAddTransaction().
    SetTopicID(topicID).
    SetNodeAccountIDs([]AccountID{response.NodeID}).
    Execute(client)
if err != nil {
    println(err.Error())
}

receipt, err := response.GetReceipt(client)
if err != nil {
    println(err.Error())
}
```

<!-- tabs:end -->

### Constructor

##### `constructor`()

---

### Properties

##### `accountId`: [`AccountId`](reference/cryptocurrency/AccountId.md)

---

##### `hash`: `bytes`

---

##### `keys`: [`Key[]`](reference/cryptography/Key.md)

---

##### `duration`: `Duration`

---

